using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XYXCommonCompatibilityEditor
{
    public static void SetCodeOptimization(string _codeOptimization, bool _webGLLTOEnable)
    {
#if UNITY_WEBGL
        string codeOptimization = string.IsNullOrEmpty(_codeOptimization) ? "Speed" : _codeOptimization;
#if UNITY_2022_1_OR_NEWER
            var targetSpeed = _webGLLTOEnable
                ? UnityEditor.WebGL.WasmCodeOptimization.RuntimeSpeedLTO
                : UnityEditor.WebGL.WasmCodeOptimization.RuntimeSpeed;
            var targetSize = _webGLLTOEnable
                ? UnityEditor.WebGL.WasmCodeOptimization.DiskSizeLTO
                : UnityEditor.WebGL.WasmCodeOptimization.DiskSize;
            var currentOpt = UnityEditor.WebGL.UserBuildSettings.codeOptimization;
            string mode = codeOptimization.ToLower();

            if (mode == "speed")
            {
                if (currentOpt == UnityEditor.WebGL.WasmCodeOptimization.BuildTimes
                    || currentOpt == UnityEditor.WebGL.WasmCodeOptimization.DiskSize
                    || currentOpt == UnityEditor.WebGL.WasmCodeOptimization.DiskSizeLTO
                    || currentOpt != targetSpeed)
                {
                    UnityEditor.WebGL.UserBuildSettings.codeOptimization = targetSpeed;
                }
            }
            else if (mode == "size")
            {
                if (currentOpt == UnityEditor.WebGL.WasmCodeOptimization.BuildTimes
                    || currentOpt == UnityEditor.WebGL.WasmCodeOptimization.RuntimeSpeed
                    || currentOpt == UnityEditor.WebGL.WasmCodeOptimization.RuntimeSpeedLTO
                    || currentOpt != targetSize)
                {
                    UnityEditor.WebGL.UserBuildSettings.codeOptimization = targetSize;
                }
            }
            else
            {
                UnityEditor.WebGL.UserBuildSettings.codeOptimization = targetSpeed;
            }
#elif UNITY_2021_1_OR_NEWER

            if (codeOptimization.ToLower() == "speed")
            {
                UnityEditor.WebGL.UserBuildSettings.codeOptimization = UnityEditor.WebGL.CodeOptimization.Speed;
            }
            else if (codeOptimization.ToLower() == "size")
            {
               UnityEditor.WebGL.UserBuildSettings.codeOptimization = UnityEditor.WebGL.CodeOptimization.Size;
            }else
            {
                UnityEditor.WebGL.UserBuildSettings.codeOptimization = UnityEditor.WebGL.CodeOptimization.Speed;
            }
#endif

#endif
    }
}
