#if ENABLEADDRESSABLE
using UnityEditor;
using UnityEngine;

/// <summary>
/// 配置 Addressables Remote.LoadPath 的动态 Provider。
/// </summary>
public class AddressableRemoteConfigWindow : EditorWindow
{
    AddressableRemoteConfig config;
    SerializedObject serializedConfig;
    SerializedProperty providerProp;

    [MenuItem("小游戏/Addressables/远程加载路径配置", false, 2599)]
    public static void Open()
    {
        var window = GetWindow<AddressableRemoteConfigWindow>("Addressables 远程配置");
        window.minSize = new Vector2(520, 200);
        window.Show();
    }

    void OnEnable()
    {
        Reload();
    }

    void Reload()
    {
        config = AddressableRemoteConfig.GetOrCreate();
        serializedConfig = new SerializedObject(config);
        providerProp = serializedConfig.FindProperty("remoteLoadPathProvider");
    }

    void OnGUI()
    {
        if (config == null || serializedConfig == null)
            Reload();

        EditorGUILayout.Space(8);
        EditorGUILayout.LabelField("Addressables Remote.LoadPath 配置", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox(
            "Provider 会写入 Profile Remote.LoadPath 的 {} 表达式，运行时可动态求值。\n" +
            $"路径后缀固定：{AddressableRemoteConfig.RemoteLoadPathSuffix}\n" +
#if XYX_TIKTOK
            $"当前平台定义了 XYX_TIKTOK，默认 Provider：{AddressableRemoteConfig.DefaultRemoteLoadPathProvider}",
#else
            "未定义 XYX_TIKTOK 时默认 Provider 为空，请按项目自行填写。",
#endif
            MessageType.Info);

        serializedConfig.Update();
        EditorGUILayout.PropertyField(providerProp, new GUIContent("Remote LoadPath Provider"));
        serializedConfig.ApplyModifiedProperties();

        EditorGUILayout.Space(6);
        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.TextField("预览 Remote.LoadPath", config.RemoteLoadPathProfileValue);
        EditorGUI.EndDisabledGroup();

        EditorGUILayout.Space(12);
        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("恢复默认", GUILayout.Height(28)))
            {
                Undo.RecordObject(config, "Reset Addressable Remote Config");
                config.RemoteLoadPathProvider = AddressableRemoteConfig.DefaultRemoteLoadPathProvider;
                EditorUtility.SetDirty(config);
                AssetDatabase.SaveAssets();
            }

            if (GUILayout.Button("保存并一键配置为远程", GUILayout.Height(28)))
            {
                EditorUtility.SetDirty(config);
                AssetDatabase.SaveAssets();
                AddressableRemoteEditor.ApplyRemoteConfigurationWithDialog();
            }
        }
    }
}
#endif
