#if ENABLEADDRESSABLE
using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Addressables 远程 LoadPath 配置。
/// Provider 可为动态运行时属性路径（写入 Profile 的 {} 表达式）。
/// 路径后缀固定为 /StreamingAssets/aa/[BuildTarget]。
/// </summary>
public class AddressableRemoteConfig : ScriptableObject
{
#if XYX_DY
    public const string DefaultRemoteLoadPathProvider = "XYXCommon.CDN.RemoteContentDistribution.RemoteLoadPath";
#elif XYX_TIKTOK
    public const string DefaultRemoteLoadPathProvider = "Tiktok.CDN.RemoteContentDistribution.RemoteLoadPath";
#else
    public const string DefaultRemoteLoadPathProvider = "";
#endif

    const string LegacyTikTokRemoteLoadPathProvider = "Tiktok.CDN.RemoteContentDistribution.RemoteLoadPath";

    public const string RemoteLoadPathSuffix = "/StreamingAssets/aa/[BuildTarget]";

    const string AssetDir = "Assets/Editor";
    const string AssetPath = AssetDir + "/AddressableRemoteConfig.asset";

    [SerializeField]
    [Tooltip("写入 Addressables Remote.LoadPath 的 {} 内属性路径，例如 XYXCommon.CDN.RemoteContentDistribution.RemoteLoadPath")]
    string remoteLoadPathProvider = DefaultRemoteLoadPathProvider;

    /// <summary>
    /// {} 内的运行时属性路径（不含大括号）。
    /// </summary>
    public string RemoteLoadPathProvider
    {
        get => NormalizeProvider(remoteLoadPathProvider);
        set => remoteLoadPathProvider = NormalizeProvider(value);
    }

    /// <summary>
    /// 生成写入 Profile Remote.LoadPath 的完整表达式。
    /// </summary>
    public string RemoteLoadPathProfileValue
    {
        get
        {
            string provider = RemoteLoadPathProvider;
            if (string.IsNullOrEmpty(provider))
                return string.Empty;

            return "{" + provider + "}" + RemoteLoadPathSuffix;
        }
    }

    public static AddressableRemoteConfig GetOrCreate()
    {
        AddressableRemoteConfig config = AssetDatabase.LoadAssetAtPath<AddressableRemoteConfig>(AssetPath);
        if (config != null)
        {
            EnsureDefaults(config);
            return config;
        }

        if (!Directory.Exists(AssetDir))
            Directory.CreateDirectory(AssetDir);

        config = CreateInstance<AddressableRemoteConfig>();
        config.remoteLoadPathProvider = DefaultRemoteLoadPathProvider;
        AssetDatabase.CreateAsset(config, AssetPath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        return config;
    }

    static void EnsureDefaults(AddressableRemoteConfig config)
    {
#if XYX_DY
        string provider = NormalizeProvider(config.remoteLoadPathProvider);
        if (string.IsNullOrWhiteSpace(config.remoteLoadPathProvider) ||
            string.Equals(provider, LegacyTikTokRemoteLoadPathProvider, System.StringComparison.Ordinal))
        {
            config.remoteLoadPathProvider = DefaultRemoteLoadPathProvider;
            EditorUtility.SetDirty(config);
            AssetDatabase.SaveAssets();
        }
#elif XYX_TIKTOK
        if (string.IsNullOrWhiteSpace(config.remoteLoadPathProvider))
        {
            config.remoteLoadPathProvider = DefaultRemoteLoadPathProvider;
            EditorUtility.SetDirty(config);
            AssetDatabase.SaveAssets();
        }
#endif
    }

    static string NormalizeProvider(string provider)
    {
        if (string.IsNullOrWhiteSpace(provider))
        {
#if XYX_DY || XYX_TIKTOK
            return DefaultRemoteLoadPathProvider;
#else
            return string.Empty;
#endif
        }

        return provider.Trim().Trim('{', '}').Trim();
    }
}
#endif
