#if ENABLEADDRESSABLE
using System;
using System.IO;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.AddressableAssets;

/// <summary>
/// Addressables 远程资源兼容处理（直接调用 Addressables Editor API）：
/// - Unity 2021：打包前 BuildPlayerContent 生成远程产物，打包后拷贝到 StreamingAssets
/// - Unity 2022+ 且 Addressables >= 1.19.4：依赖「Build Addressables on Player Build」，打包后只拷贝远程产物
/// - 旧版 Addressables：仍显式构建远程产物
/// </summary>
public static class AddressableRemoteEditor
{
    const string DefaultRemoteBuildFolder = "ServerData";
#if XYX_ADDRESSABLES_1_19_4_OR_NEWER
    const string DefaultRemoteBuildPathValue = AddressableAssetSettings.kRemoteBuildPathValue;
#else
    const string DefaultRemoteBuildPathValue = DefaultRemoteBuildFolder + "/[BuildTarget]";
#endif
    const string LegacyTikTokRemoteLoadPathProvider = "Tiktok.CDN.RemoteContentDistribution.RemoteLoadPath";

    /// <summary>
    /// 应用远程配置并弹出结果提示（供配置窗口调用）。
    /// </summary>
    public static void ApplyRemoteConfigurationWithDialog()
    {
        if (!ApplyRemoteConfiguration())
        {
            EditorUtility.DisplayDialog("Addressables 远程配置", "配置失败，请查看 Console 日志。", "确定");
            return;
        }

        string remoteLoadPath = AddressableRemoteConfig.GetOrCreate().RemoteLoadPathProfileValue;
        EditorUtility.DisplayDialog(
            "Addressables 远程配置",
            "已按当前激活 Profile 配置为远程：\n" +
            $"- {AddressableAssetSettings.kRemoteBuildPath} = {DefaultRemoteBuildPathValue}\n" +
            $"- {AddressableAssetSettings.kRemoteLoadPath} = {remoteLoadPath}\n" +
            "- 所有 Bundled Group 的 Build/Load Path 指向 Remote\n" +
            "- 已开启 Build Remote Catalog",
            "确定");
    }

    /// <summary>
    /// 一键把 Addressables 改成远程配置（基于当前激活 Profile）。
    /// Remote.LoadPath 读取 AddressableRemoteConfig（抖音默认使用 XYXGlobalConfig CDN Provider）。
    /// </summary>
    public static bool ApplyRemoteConfiguration()
    {
        if (!TryGetActiveProfile(out AddressableAssetSettings settings, out string profileId, out string profileName))
            return false;

        AddressableRemoteConfig remoteConfig = AddressableRemoteConfig.GetOrCreate();
        string remoteLoadPathValue = remoteConfig.RemoteLoadPathProfileValue;
        if (string.IsNullOrEmpty(remoteLoadPathValue))
        {
            Debug.LogError(
                "[AddressableRemoteEditor] Remote LoadPath Provider 为空。" +
                "请先通过菜单「小游戏/Addressables/远程加载路径配置」填写 Provider。");
            return false;
        }

        try
        {
            Undo.RecordObject(settings, "Apply Addressables Remote Config");

            EnsureProfileVariable(
                settings,
                profileId,
                AddressableAssetSettings.kRemoteBuildPath,
                DefaultRemoteBuildPathValue);
            EnsureProfileVariable(
                settings,
                profileId,
                AddressableAssetSettings.kRemoteLoadPath,
                remoteLoadPathValue);

            settings.BuildRemoteCatalog = true;
            settings.RemoteCatalogBuildPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteBuildPath);
            settings.RemoteCatalogLoadPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteLoadPath);

#if UNITY_2022_1_OR_NEWER && XYX_ADDRESSABLES_1_19_4_OR_NEWER
            settings.BuildAddressablesWithPlayerBuild = AddressableAssetSettings.PlayerBuildOption.BuildWithPlayer;
#endif

            int groupCount = 0;
            foreach (AddressableAssetGroup group in settings.groups)
            {
                if (group == null || group.ReadOnly)
                    continue;

                BundledAssetGroupSchema schema = group.GetSchema<BundledAssetGroupSchema>();
                if (schema == null)
                    continue;

                Undo.RecordObject(schema, "Apply Addressables Remote Config");
                schema.BuildPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteBuildPath);
                schema.LoadPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteLoadPath);
                EditorUtility.SetDirty(schema);
                groupCount++;
            }

            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Debug.Log(
                $"[AddressableRemoteEditor] 已将激活 Profile「{profileName}」配置为远程：" +
                $"{AddressableAssetSettings.kRemoteBuildPath}={DefaultRemoteBuildPathValue}，" +
                $"{AddressableAssetSettings.kRemoteLoadPath}={remoteLoadPathValue}，" +
                $"已更新 {groupCount} 个 Group，BuildRemoteCatalog=true");
            return true;
        }
        catch (Exception e)
        {
            Debug.LogError($"[AddressableRemoteEditor] 一键配置远程失败: {e}");
            return false;
        }
    }

    /// <summary>
    /// 抖音旧版配置曾错误引用 TikTok CDN Provider。只迁移这个已知值，保留用户自定义 Provider。
    /// </summary>
    public static bool MigrateLegacyRemoteLoadPath()
    {
#if !XYX_DY
        return false;
#else
        if (!TryGetActiveProfile(out AddressableAssetSettings settings, out string profileId, out string profileName))
            return false;

        AddressableAssetProfileSettings profileSettings = settings.profileSettings;
        string rawValue = profileSettings.GetValueByName(profileId, AddressableAssetSettings.kRemoteLoadPath);
        if (string.IsNullOrEmpty(rawValue) ||
            rawValue.IndexOf(LegacyTikTokRemoteLoadPathProvider, StringComparison.Ordinal) < 0)
        {
            return false;
        }

        string migratedValue = rawValue.Replace(
            LegacyTikTokRemoteLoadPathProvider,
            AddressableRemoteConfig.DefaultRemoteLoadPathProvider);
        profileSettings.SetValue(profileId, AddressableAssetSettings.kRemoteLoadPath, migratedValue);
        EditorUtility.SetDirty(settings);
        AssetDatabase.SaveAssets();

        Debug.Log(
            $"[AddressableRemoteEditor] 已迁移 Profile「{profileName}」的 Remote.LoadPath：" +
            $"{rawValue} -> {migratedValue}");
        return true;
#endif
    }

    static void EnsureProfileVariable(
        AddressableAssetSettings settings,
        string profileId,
        string variableName,
        string value)
    {
        AddressableAssetProfileSettings profileSettings = settings.profileSettings;
        if (!profileSettings.GetVariableNames().Contains(variableName))
            profileSettings.CreateValue(variableName, value);

        profileSettings.SetValue(profileId, variableName, value);
    }

    /// <summary>
    /// 打包前按 Unity 和 Addressables 版本决定是否显式构建远程内容。
    /// </summary>
    public static bool BuildRemoteAddressablesContentIfNeeded()
    {
#if UNITY_2022_1_OR_NEWER && XYX_ADDRESSABLES_1_19_4_OR_NEWER
        Debug.Log("[AddressableRemoteEditor] Unity 2022+：跳过显式 Addressables 构建，依赖 Player Build 自动 build，打包后仅拷贝远程产物");
        return true;
#else
        return BuildRemoteAddressablesContent();
#endif
    }

    /// <summary>
    /// Unity 2021 或旧版 Addressables：直接调用 AddressableAssetSettings.BuildPlayerContent。
    /// </summary>
    static bool BuildRemoteAddressablesContent()
    {
        if (AddressableAssetSettingsDefaultObject.Settings == null)
        {
            Debug.Log("[AddressableRemoteEditor] 工程未配置 AddressableAssetSettings，跳过构建");
            return true;
        }

        try
        {
            Debug.Log("[AddressableRemoteEditor] 显式构建 Addressables 远程内容");
            AddressableAssetSettings.CleanPlayerContent();
            AddressableAssetSettings.BuildPlayerContent(out AddressablesPlayerBuildResult result);
            if (result != null && !string.IsNullOrEmpty(result.Error))
            {
                Debug.LogError($"[AddressableRemoteEditor] Addressables 远程内容构建失败: {result.Error}");
                return false;
            }

            string outputPath = GetRemoteBuildOutputPath();
            if (string.IsNullOrEmpty(outputPath) || !Directory.Exists(outputPath) ||
                Directory.GetFiles(outputPath, "*", SearchOption.AllDirectories).Length == 0)
            {
                Debug.LogWarning($"[AddressableRemoteEditor] Addressables 构建完成，但未找到输出: {outputPath}");
            }
            else
            {
                Debug.Log($"[AddressableRemoteEditor] Addressables 远程内容构建完成: {outputPath}");
            }

            AssetDatabase.Refresh();
            return true;
        }
        catch (Exception e)
        {
            Debug.LogError($"[AddressableRemoteEditor] Addressables 远程内容构建异常: {e}");
            return false;
        }
    }

    /// <summary>
    /// 将 Remote.BuildPath 产物拷贝到 exportRoot/StreamingAssets/{aa 相对路径}。
    /// </summary>
    public static void CopyRemoteAddressablesToStreamingAssets(string exportRoot)
    {
        if (string.IsNullOrWhiteSpace(exportRoot))
        {
            Debug.LogWarning("[AddressableRemoteEditor] exportRoot 为空，跳过 Addressables 拷贝");
            return;
        }

        string sourcePath = GetRemoteBuildOutputPath();
        if (string.IsNullOrEmpty(sourcePath) || !Directory.Exists(sourcePath))
        {
#if UNITY_2022_1_OR_NEWER && XYX_ADDRESSABLES_1_19_4_OR_NEWER
            Debug.LogWarning($"[AddressableRemoteEditor] 未找到远程产物，请确认已开启 Build Addressables on Player Build，且 Remote.BuildPath 正确: {sourcePath}");
#else
            Debug.Log($"[AddressableRemoteEditor] 未找到 Addressables 远程构建产物，跳过拷贝: {sourcePath}");
#endif
            return;
        }

        string relativeDest = GetStreamingAssetsRelativeDestPath();
        string destPath = Path.GetFullPath(Path.Combine(exportRoot, "StreamingAssets", relativeDest));

        string destParent = Path.GetDirectoryName(destPath);
        if (!string.IsNullOrEmpty(destParent) && !Directory.Exists(destParent))
            Directory.CreateDirectory(destParent);

        if (Directory.Exists(destPath))
            Directory.Delete(destPath, true);

        CopyDirectory(sourcePath, destPath);
        Debug.Log($"[AddressableRemoteEditor] 已拷贝 Addressables 远程资源:\n  源(Remote.BuildPath): {sourcePath}\n  目标: {destPath}");
    }

    /// <summary>
    /// 获取 Remote.BuildPath 求值后的绝对路径。
    /// </summary>
    public static string GetRemoteBuildOutputPath()
    {
        string projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
        if (string.IsNullOrEmpty(projectRoot))
            return null;

        string evaluated = EvaluateProfileVariable(AddressableAssetSettings.kRemoteBuildPath);
        if (string.IsNullOrEmpty(evaluated))
        {
            evaluated = Path.Combine(DefaultRemoteBuildFolder, EditorUserBuildSettings.activeBuildTarget.ToString());
            Debug.Log($"[AddressableRemoteEditor] 未读到激活 Profile 的 {AddressableAssetSettings.kRemoteBuildPath}，使用默认: {evaluated}");
        }

        evaluated = evaluated.Replace('\\', '/').Trim('/');
        if (Path.IsPathRooted(evaluated))
            return Path.GetFullPath(evaluated);

        return Path.GetFullPath(Path.Combine(projectRoot, evaluated));
    }

    /// <summary>
    /// StreamingAssets 下的相对目标路径，例如 aa/WebGL。
    /// </summary>
    public static string GetStreamingAssetsRelativeDestPath()
    {
        string buildTarget = EditorUserBuildSettings.activeBuildTarget.ToString();
        string loadPath = GetRemoteLoadPath();
        if (!string.IsNullOrEmpty(loadPath))
        {
            string normalized = loadPath.Replace('\\', '/');
            const string marker = "/StreamingAssets/";
            int index = normalized.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (index >= 0)
            {
                string relative = normalized.Substring(index + marker.Length).Trim('/');
                if (!string.IsNullOrEmpty(relative) && !relative.Contains("{"))
                    return relative.Replace('/', Path.DirectorySeparatorChar);
            }
        }

        return Path.Combine(Addressables.StreamingAssetsSubFolder, buildTarget);
    }

    /// <summary>
    /// 获取当前激活 Profile 的 Remote.LoadPath（可能仍含运行时 {} 占位）。
    /// </summary>
    public static string GetRemoteLoadPath()
    {
        return EvaluateProfileVariable(AddressableAssetSettings.kRemoteLoadPath);
    }

    /// <summary>
    /// 读取并求值「当前激活 Profile」中的变量。
    /// 多 Profile 时始终以 AddressableAssetSettings.activeProfileId 为准。
    /// </summary>
    public static string EvaluateProfileVariable(string variableName)
    {
        if (!TryGetActiveProfile(out AddressableAssetSettings settings, out string profileId, out string profileName))
            return null;

        AddressableAssetProfileSettings profileSettings = settings.profileSettings;
        string rawValue = profileSettings.GetValueByName(profileId, variableName);
        if (string.IsNullOrEmpty(rawValue))
            return null;

        string evaluated = profileSettings.EvaluateString(profileId, rawValue);
        string result = string.IsNullOrEmpty(evaluated) ? rawValue : evaluated;
        Debug.Log($"[AddressableRemoteEditor] 使用激活 Profile「{profileName}」求值 {variableName} = {result}");
        return result;
    }

    /// <summary>
    /// 解析并校验当前激活的 Addressables Profile。
    /// </summary>
    static bool TryGetActiveProfile(out AddressableAssetSettings settings, out string profileId, out string profileName)
    {
        settings = AddressableAssetSettingsDefaultObject.Settings;
        profileId = null;
        profileName = null;

        if (settings == null)
        {
            Debug.LogWarning("[AddressableRemoteEditor] 工程未配置 AddressableAssetSettings");
            return false;
        }

        AddressableAssetProfileSettings profileSettings = settings.profileSettings;
        if (profileSettings == null)
        {
            Debug.LogWarning("[AddressableRemoteEditor] profileSettings 为空");
            return false;
        }

        profileId = settings.activeProfileId;
        if (string.IsNullOrEmpty(profileId))
        {
            Debug.LogWarning("[AddressableRemoteEditor] 未设置激活 Profile（activeProfileId 为空）");
            return false;
        }

        profileName = profileSettings.GetProfileName(profileId);
        if (string.IsNullOrEmpty(profileName))
        {
            Debug.LogWarning($"[AddressableRemoteEditor] activeProfileId={profileId} 不在现有 Profiles 中，请在 Addressables Groups 窗口重新选择激活 Profile");
            return false;
        }

        return true;
    }

    static void CopyDirectory(string sourceDir, string destDir)
    {
        Directory.CreateDirectory(destDir);

        foreach (string file in Directory.GetFiles(sourceDir))
        {
            string fileName = Path.GetFileName(file);
            if (fileName.EndsWith(".meta"))
                continue;

            File.Copy(file, Path.Combine(destDir, fileName), true);
        }

        foreach (string dir in Directory.GetDirectories(sourceDir))
        {
            CopyDirectory(dir, Path.Combine(destDir, Path.GetFileName(dir)));
        }
    }
}

/// <summary>
/// 确保升级 SDK 后，即使没有重新点击一键配置，旧 Profile 也会在构建 Addressables 前完成迁移。
/// </summary>
public sealed class AddressableRemoteBuildPreprocessor : IPreprocessBuildWithReport
{
    public int callbackOrder => -10000;

    public void OnPreprocessBuild(BuildReport report)
    {
        AddressableRemoteEditor.MigrateLegacyRemoteLoadPath();
    }
}

#else
public static class AddressableRemoteEditor
{
    public static bool BuildRemoteAddressablesContentIfNeeded()
    {
        return true;
    }
    public static void CopyRemoteAddressablesToStreamingAssets(string exportRoot)
    {
        return;
    }
}
#endif
