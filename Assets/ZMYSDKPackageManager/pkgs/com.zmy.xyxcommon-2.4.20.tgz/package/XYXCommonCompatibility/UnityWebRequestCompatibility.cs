using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace XYXCommon
{
    public class UnityWebRequestCompatibility
    {
        public static UnityWebRequest Post(Uri host, string data)
        {
#if UNITY_2022_1_OR_NEWER
            return UnityWebRequest.PostWwwForm(host, data);
#else
            return UnityWebRequest.Post(host, data);
#endif
        }
        public static UnityWebRequest Post(string host, string data)
        {
#if UNITY_2022_1_OR_NEWER
            return UnityWebRequest.PostWwwForm(host, data);
#else
            return UnityWebRequest.Post(host, data);
#endif
        }

    }
}
