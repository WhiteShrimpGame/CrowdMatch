using System;
using System.Collections;
using System.Collections.Generic;
using GravityEngine;
using GravitySDK.PC.Constant;
using UnityEngine;
namespace XYXCommon
{
    public class GravityEngineAdapt
    {
        // This assembly is shipped as source. Evaluate platform support in the game,
        // not while publishing the shared XYXCommon DLL. Do not make this a const.
        public static bool IsPlatformSupported
        {
            get
            {
#if GRAVITY_WECHAT_GAME_MODE || GRAVITY_BILIBILI_GAME_MODE || GRAVITY_BYTEDANCE_GAME_MODE || GRAVITY_BYTEDANCE_TT_GAME_MODE || GRAVITY_KUAISHOU_GAME_MODE || GRAVITY_KUAISHOU_WEBGL_GAME_MODE || GRAVITY_OPPO_GAME_MODE || GRAVITY_ALIPAY_GAME_MODE || GRAVITY_HUAWEI_GAME_MODE
                return true;
#else
                return false;
#endif
            }
        }

        private static string AccessToken;
        private static string OpenID;
        private static string AppVersion;
        private static string Channel;
        static bool IsDebugMode;
        public static void CreateGravityEngine(string _accessToken,string _openid,string app_version,string channel,IDynamicSuperProperties dynamicSuperProperties,bool isDebugMode)
        {
            AccessToken = _accessToken;
            OpenID = _openid;
            AppVersion = app_version;
            Channel = channel;
            IsDebugMode = isDebugMode;

#if GRAVITY_WECHAT_GAME_MODE || GRAVITY_BILIBILI_GAME_MODE || GRAVITY_BYTEDANCE_GAME_MODE || GRAVITY_BYTEDANCE_TT_GAME_MODE || GRAVITY_KUAISHOU_GAME_MODE || GRAVITY_KUAISHOU_WEBGL_GAME_MODE || GRAVITY_OPPO_GAME_MODE || GRAVITY_ALIPAY_GAME_MODE || GRAVITY_HUAWEI_GAME_MODE
            Debug.Log($"[GravityInit] InitGravity start. tokenLength={AccessToken?.Length ?? 0}, hasOpenId={!string.IsNullOrWhiteSpace(OpenID)}, appVersion={AppVersion}, channel={Channel}, debugMode={IsDebugMode}");
            // 手动初始化（动态挂载 GravityEngineAPI 脚本）
            new GameObject("GravityEngine", typeof(GravityEngineAPI));
            // 微信小游戏示例
            //设置实例参数并启动引擎，将以下三个参数修改成您应用对应的参数，参数可以在引力后台--管理中心--应用管理中查看
            string accessToken = AccessToken; // 项目通行证，在：网站后台-->管理中心-->应用列表中找到Access Token列 复制（首次使用可能需要先新增应用）
            string clientId = OpenID; // 通常是某一个用户的唯一标识，比如抖音小游戏中的 openId
            // 启动引力引擎
            GravityEngineAPI.StartGravityEngine(accessToken, clientId, isDebugMode ? GravityEngineAPI.SDKRunMode.DEBUG : GravityEngineAPI.SDKRunMode.NORMAL);
            // 开启自动采集，并设置自定属性
            
            GravityEngineAPI.SetDynamicSuperProperties(dynamicSuperProperties);
            EnableAutoTrackForPlatform(GetTrackEventsByChannel());
#else
            Debug.LogWarning("[GravityInit] CreateGravityEngine skipped. No supported Gravity platform define in the game adaptation assembly.");
#endif
        }

        
        public static void Initialize(IInitializeCallback initializeCallback)
        {
            if (!IsPlatformSupported)
            {
                initializeCallback?.onFailed("No supported Gravity platform define in the game adaptation assembly.");
                return;
            }
            Debug.Log("[GravityInit] Initialize enter. Parsing appVersion=" + AppVersion);
            System.Version version = new System.Version(AppVersion);
            int versionInt = version.Major * 10000 + version.Minor * 100 + version.Build;
            Debug.Log("[GravityInit] Calling GravityEngineAPI.Initialize. versionInt=" + versionInt);
            /// <summary>
            /// 在引力引擎初始化，其他方法均需在本方法回调成功之后才可正常使用
            /// </summary>

            /// <param name="clientId"></param>                 用户唯一标识，如产品为小游戏，则必须填用户openid(如传空，则使用调用StartGravityEngine时传入的clientID；如传，则会使用当前传入的clientID)
            /// <param name="nickname"></param>                 用户昵称
            /// <param name="version"></param>                  用户注册的程序版本，比如当前小游戏的版本号
            /// <param name="openId"></param>                   open id (小程序/小游戏必填)
            /// <param name="enableSyncAttribution"></param>   开启之后极端情况会有长达 10s 的接口阻塞，请谨慎开启！ 是否开启同步获取归因信息，具体请参考同步归因：https://doc.gravity-engine.com/turbo-integrated/sync_attribution.html
            /// <param name="initializeCallback"></param>       网络回调，其他方法均需在回调成功之后才可正常使用
            /// <exception cref="ArgumentException"></exception>
            GravityEngineAPI.Initialize(OpenID, OpenID, versionInt, OpenID, false, initializeCallback);
        }
        
#if GRAVITY_WECHAT_GAME_MODE || GRAVITY_BILIBILI_GAME_MODE || GRAVITY_BYTEDANCE_GAME_MODE || GRAVITY_BYTEDANCE_TT_GAME_MODE || GRAVITY_KUAISHOU_GAME_MODE || GRAVITY_KUAISHOU_WEBGL_GAME_MODE || GRAVITY_OPPO_GAME_MODE || GRAVITY_ALIPAY_GAME_MODE || GRAVITY_HUAWEI_GAME_MODE
        /// <summary>
        /// 获取TRACK_EVENTS根据Channel
        /// </summary>
        /// <param name="channel"></param>
        /// <returns></returns>
        private static AUTO_TRACK_EVENTS GetTrackEventsByChannel()
        {
            switch (Channel)
            {
#if GRAVITY_WECHAT_GAME_MODE
                case "weixin":
                    return AUTO_TRACK_EVENTS.WECHAT_GAME_ALL;
#endif

#if GRAVITY_BYTEDANCE_GAME_MODE || GRAVITY_BYTEDANCE_TT_GAME_MODE
                case "zijie":
                    return AUTO_TRACK_EVENTS.BYTEDANCE_GAME_ALL;
#endif

#if GRAVITY_KUAISHOU_GAME_MODE || GRAVITY_KUAISHOU_WEBGL_GAME_MODE
                case "kuaishou":
                case "kuaishou_foreign":
                    return AUTO_TRACK_EVENTS.MINI_GAME_ALL;
#endif

#if GRAVITY_OPPO_GAME_MODE || GRAVITY_HUAWEI_GAME_MODE ||GRAVITY_XIAOMI_GAME_MODE
                case "huawei":
                case "oppo":
                    return AUTO_TRACK_EVENTS.OPPO_GAME_ALL;
#endif
                default:
                    return AUTO_TRACK_EVENTS.NONE;
            }
        }
#endif
        private static void EnableAutoTrackForPlatform(AUTO_TRACK_EVENTS events)
        {

            Debug.Log($"[GravityInit] InitGravity EnableAutoTrack {Channel}");
            GravityEngineAPI.EnableAutoTrack(events, new Dictionary<string, object>
            {
                {"$app_version", AppVersion}
            });
        }

        

    }
}
