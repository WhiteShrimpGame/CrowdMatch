﻿using UnityEditor;
using System.Threading.Tasks;
using UnityEditor.Build.Content;
using UnityEngine;

namespace UnityBridger
{
    public static partial class UnityInternalAPIEngineBridger
    {
        public static async void OpenProjectSettingsWindow(string path)
        {
            ProjectSettingsWindow projectSettingsWindow = EditorWindow.GetWindow<ProjectSettingsWindow>();
            projectSettingsWindow.Show();

            await Task.Delay(1);
            projectSettingsWindow.SelectProviderByName(path);
        }

        public static void SetTextureCompression()
        {
            bool changed = false;

            // Unity 2021 / WebGL 平台
            if (EditorUserBuildSettings.webGLBuildSubtarget != WebGLTextureSubtarget.ASTC)
            {
                EditorUserBuildSettings.webGLBuildSubtarget = WebGLTextureSubtarget.ASTC;
                changed = true;
                Debug.Log("SetTextureCompression:强制修改webgl为ASTC格式");
            }
#if WEIXINMINIGAME
            // 团结引擎 2022+ / 微信小游戏平台
            if (EditorUserBuildSettings.weixinMiniGameBuildSubtarget != WebGLTextureSubtarget.ASTC)
            {
                EditorUserBuildSettings.weixinMiniGameBuildSubtarget = WebGLTextureSubtarget.ASTC;
                changed = true;
                Debug.Log("SetTextureCompression:强制修改微信小游戏为ASTC格式");
            }
#endif

            if (changed)
            {
                AssetDatabase.Refresh();
                AssetDatabase.SaveAssets();
            }
        }
    }
}