using UnityEngine;
using System;
using System.IO;
// using System.Xml;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace GravityEngine.Utils
{
    // 三方数据共享类型
    public enum GEThirdPartyShareType
    {
        NONE = 0,
        APPSFLYER = 1 << 0, // AppsFlyer
        IRONSOURCE = 1 << 1, // IronSource
        ADJUST = 1 << 2, // Adjust
        BRANCH = 1 << 3, // Branch
        TOPON = 1 << 4, // TopOn
        TRACKING = 1 << 5, // 热云
        TRADPLUS = 1 << 6, // TradPlus
    };

    // SSL认证方式类型
    public enum SSLPinningMode
    {
        NONE = 0, // 默认认证方式，只会在系统的信任的证书列表中对服务端返回的证书进行验证
        PUBLIC_KEY = 1 << 0, // 校验证书的公钥
        CERTIFICATE = 1 << 1 // 校验证书的所有内容
    }

    public class GE_PublicConfig
    {
        public static bool DisableCSharpException = false;
        public static List<string> DisPresetProperties = new List<string>();

        public static readonly string LIB_VERSION = "4.8.23";

        public static void GetPublicConfig()
        {
            TextAsset textAsset = Resources.Load<TextAsset>("ge_public_config");
            if (textAsset != null && !string.IsNullOrEmpty(textAsset.text))
            {
               string xml = textAsset.text;

                // 先去掉 XML 注释，避免匹配到被注释掉的 string-array、item、bool
                string xmlNoComments = Regex.Replace(xml, @"<!--.*?-->", string.Empty,
                    RegexOptions.Singleline);
                //新的正则匹配方式，比XmlDocument更高效
                var arrayMatch = Regex.Match(xmlNoComments,
                    @"<string-array\s+name\s*=\s*""GEDisPresetProperties""[^>]*>(.*?)</string-array>",
                    RegexOptions.Singleline);
                if (arrayMatch.Success)
                {
                    var items = Regex.Matches(arrayMatch.Groups[1].Value, @"<item>(.*?)</item>");
                    for (int i = 0; i < items.Count; i++)
                    {
                        // Debug.Log("DisPresetProperties: " + items[i].Groups[1].Value);
                        DisPresetProperties.Add(items[i].Groups[1].Value);
                    }
                }

                var boolMatch = Regex.Match(xmlNoComments,
                    @"<bool\s+name\s*=\s*""DisableCSharpException""[^>]*>(.*?)</bool>");
                if (boolMatch.Success)
                {
                    // Debug.Log("DisableCSharpException: " + boolMatch.Groups[1].Value.Trim());
                    DisableCSharpException = Convert.ToBoolean(boolMatch.Groups[1].Value.Trim());
                }
                Debug.Log($"DisPresetProperties-regex: {string.Join(",", DisPresetProperties)}");
                Debug.Log($"DisableCSharpException-regex: {DisableCSharpException}");

                // //旧的XmlDocument匹配方式，备用
                // DisableCSharpException=false;
                // DisPresetProperties.Clear();
                // XmlDocument xmlDoc = new XmlDocument();
                // xmlDoc.LoadXml(textAsset.text);
                // XmlNode root = xmlDoc.SelectSingleNode("resources");
                // //遍历节点
                // for (int i = 0; i < root.ChildNodes.Count; i++)
                // {
                //     XmlNode x1 = root.ChildNodes[i];
                //     if (x1.NodeType == XmlNodeType.Element)
                //     {
                //         XmlElement e1 = x1 as XmlElement;
                //         if (e1.HasAttributes)
                //         {
                //             string name = e1.GetAttribute("name");
                //             if (name == "GEDisPresetProperties" && e1.HasChildNodes)
                //             {
                //                 for (int j = 0; j < e1.ChildNodes.Count; j++)
                //                 {
                //                     XmlNode x2 = e1.ChildNodes[j];
                //                     if (x2.NodeType == XmlNodeType.Element)
                //                     {
                //                         DisPresetProperties.Add(x2.InnerText);
                //                     }
                //                 }
                //             }
                //             else if (name == "DisableCSharpException")
                //             {
                //                 DisableCSharpException = Convert.ToBoolean(e1.InnerText);
                //             }
                //         }
                //     }
                // }
                // Debug.Log($"DisPresetProperties-xml: {string.Join(",", DisPresetProperties)}");
                // Debug.Log($"DisableCSharpException-xml: {DisableCSharpException}");
            }
        }
    }
}