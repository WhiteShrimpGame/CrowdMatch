using System;
using System.Collections;
using System.Collections.Generic;
using GravityEngine;
using GravityEngine.Utils;
using GravitySDK.PC.TaskManager;
using GravitySDK.PC.Utils;
#if GRAVITY_OPPO_GAME_MODE
using QGMiniGame;
#endif
using UnityEngine;
using UnityEngine.Networking;

namespace GravitySDK.PC.GravityTurbo
{
    public static class GravityHelper
    {
        private const string GravityHost = "https://backend.gravity-engine.com";
        private const string dev_host = "https://event-test-backend.gravity-engine.com";
        private static string _accessToken;
        private static string _clientID;
        private static string _channel;
        private static int _silentPeriod = 7;
        private static bool _enableSilentPeriod;
        private static bool _isTencentDryRunModeEnabled = false;

        private static void GlobalCheck()
        {
            if (string.IsNullOrEmpty(_accessToken))
            {
                throw new ArgumentException("accessToken must be required");
            }

            if (string.IsNullOrEmpty(_clientID))
            {
                throw new ArgumentException("clientId must be required");
            }
        }

        /// <summary>
        /// 初始化GravityHelper SDK必须参数（每次启动都需要调用）
        /// </summary>
        /// <param name="accessToken">项目通行证，在：网站后台-->管理中心-->应用列表中找到Access Token列 复制（首次使用可能需要先新增应用）</param> 
        /// <param name="clientId">用户唯一标识，如微信小程序/小游戏的openid、Android ID、iOS的IDFA、或业务侧自行生成的唯一用户ID均可</param>
        /// <param name="channel">用户渠道</param>
        public static void InitSDK(string accessToken, string clientId, string channel)
        {
            _accessToken = accessToken;
            _clientID = clientId;
            _channel = channel;
            GlobalCheck();
            GravitySDKLogger.Print("GravityHelper init success");
        }

        public static void Initialize(string clientId, string name, int version, string openId, Dictionary<string, string> wxLaunchQuery, bool enableSyncAttribution,
            IInitializeCallback initializeCallback, UnityWebRequestMgr.Callback callback)
        {
            // check params
            GlobalCheck();
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException("name must be required");
            }

            var currentClientId = SetOrGetClientId(clientId);
            var registerRequestDir = new Dictionary<string, object>()
            {
                {"client_id", currentClientId},
                {"name", name},
                {"channel", _channel},
                {"version", version},
                {"wx_openid", openId},
                {"wx_unionid", ""},
                {"ad_data", wxLaunchQuery},
                {"need_return_attribution", enableSyncAttribution},
            };
#if GRAVITY_OPPO_GAME_MODE
            string deviceId = "";
            QG.GetDeviceId(
                (success) =>
                {
                    deviceId = success.data.deviceId; //设备唯一标识
                },
                (fail) =>
                {
                    Debug.Log("QG.GetDeviceId fail = " + JsonUtility.ToJson(fail));
                },
                (complete) =>
                {
                    Debug.Log("gravity-engine current deviceId is " + deviceId);
                    QG.GetSystemInfo((msg) =>
                        {
                            string brand = msg.data.brand; // 手机品牌
                            string language = msg.data.language; // 系统语言
                            string model = msg.data.model; // 手机型号
                            string platformVersionName = msg.data.platformVersionName; // 客户端平台
                            string platformVersionCode = msg.data.platformVersionCode; // Version
                            string screenHeight = msg.data.screenHeight; // 屏幕高度
                            string screenWidth = msg.data.screenWidth; // 屏幕宽度
                            string system = msg.data.system; // 系统版本
                            string COREVersion = msg.data.COREVersion; // 版本号
                            
                            var deviceInfo = new Dictionary<string, string>()
                            {
                                {"os_name", "android"},
                                {"android_id", deviceId},
                                {"imei", deviceId},
                                {"oaid", deviceId},
                                {"rom", platformVersionName},
                                {"rom_version", platformVersionCode},
                                {"brand", brand},
                                {"model", model},
                                {"android_version", COREVersion}
                            };
                            registerRequestDir["device_info"] = deviceInfo;
                            RequestInitialize(initializeCallback, callback, currentClientId, registerRequestDir);
                        },
                        (err) =>
                        {
                            Debug.Log("QG.GetSystemInfo fail = " + JsonUtility.ToJson(err));
                            var deviceInfo = new Dictionary<string, string>()
                            {
                                {"os_name", "android"},
                                {"android_id", deviceId},
                                {"imei", deviceId},
                                {"oaid", deviceId},
                            };
                            registerRequestDir["device_info"] = deviceInfo;
                            RequestInitialize(initializeCallback, callback, currentClientId, registerRequestDir);
                        });
                });
#else
            RequestInitialize(initializeCallback, callback, currentClientId, registerRequestDir);
#endif
        }

        private static void RequestInitialize(IInitializeCallback initializeCallback, UnityWebRequestMgr.Callback callback, string currentClientId,
            Dictionary<string, object> registerRequestDir)
        {
            var body = GE_MiniJson.Serialize(registerRequestDir);
            var url = GravityHost + "/event_center/api/v1/user/initialize/?access_token=" + _accessToken +
                      "&client_id=" + currentClientId;
            Debug.Log("url is " + url);
            Debug.Log("body is " + body);

            Debug.LogWarning("url is " + url);
            Debug.LogWarning("body is " + body);

            UnityWebRequestMgr.Instance.Post(url, registerRequestDir, (request =>
                {
                    string responseText = request.downloadHandler.text;
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    GravitySDKLogger.Print("response is " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                if (res.TryGetValue("data", out object dataObj))
                                {
                                    initializeCallback?.onSuccess((Dictionary<string, object>) dataObj);
                                }
                                else
                                {
                                    initializeCallback?.onSuccess(new Dictionary<string, object>());
                                }
                                return;
                            }
                        }
                    }

                    initializeCallback?.onFailed("code is not 0, failed with msg " + res?["msg"]);
                }), callback);
        }
        
        
        public static void GetOpenId(string code, string accessToken, IGetOpenIdCallback getOpenIdCallback)
        {
#if GRAVITY_WECHAT_GAME_MODE
            string platformStr = "wx";
#elif GRAVITY_BYTEDANCE_GAME_MODE || GRAVITY_BYTEDANCE_TT_GAME_MODE
            string platformStr = "dy";
#elif GRAVITY_KUAISHOU_GAME_MODE || GRAVITY_KUAISHOU_WEBGL_GAME_MODE
            string platformStr = "ks";
#else
            string platformStr = null;
#endif
            if (getOpenIdCallback == null)
            {
                GravitySDKLogger.Print("Callback error");
                return;
            }
            if (platformStr == null)
            {
                getOpenIdCallback.onFailed("平台类型错误，请检查是否正确添加全局宏参数：GRAVITY_WECHAT_GAME_MODE、GRAVITY_BYTEDANCE_GAME_MODE、GRAVITY_BYTEDANCE_TT_GAME_MODE、GRAVITY_KUAISHOU_GAME_MODE、GRAVITY_KUAISHOU_WEBGL_GAME_MODE");
            }
            else
            {
                var requestDir = new Dictionary<string, object>()
                {
                    {"code", code},
                };
                UnityWebRequestMgr.Instance.Post(
                    GravityHost + "/event_center/api/v1/base/"+ platformStr + "/code2Session/?access_token=" + accessToken, requestDir,
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    // string responseText = "{\n  \"data\": {\n    \"resp\": {\n      \"session_key\": \"wHVdBZh5CmqKTl7zTnloSg==\",\n      \"openid\": \"oeleK67L8sN8MIqAkZa2fkPftyvs\",\n      \"unionid\": \"oaNSjv-v854AXW_1W41MZv3sSwKU\"\n    }\n  },\n  \"extra\": {},\n  \"code\": 0,\n  \"msg\": \"成功\"\n}";
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                if (res.TryGetValue("data", out object dataObj))
                                {
                                    Dictionary<string, object> dataDict = (Dictionary<string, object>) dataObj;
                                    // foreach (var kvp in dataDict)
                                    // {
                                    //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                    // }
                                    if (dataDict.TryGetValue("resp", out object respObj))
                                    {
                                        // Dictionary<string, object> respDict = (Dictionary<string, object>) respObj;
                                        // foreach (var kvp in respDict)
                                        // {
                                        //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                        // }
                                        getOpenIdCallback?.onSuccess((Dictionary<string, object>) respObj);
                                    }
                                    else
                                    {
                                        getOpenIdCallback?.onSuccess(new Dictionary<string, object>());
                                    }
                                }
                                else
                                {
                                    getOpenIdCallback?.onSuccess(new Dictionary<string, object>());
                                }
                                return;
                            }
                        }
                    }

                    getOpenIdCallback?.onFailed("code is not 0, failed with msg " + res?["msg"]);
                }));
            }
        }
        
        public static String GetAccessToken()
        {
            return _accessToken;
        }

        public static String GetClientId()
        {
            return _clientID;
        }
        
        /// <summary>
        /// 如果传入的currentClientId不为空，则set到_clientID，否则直接返回当前的_clientId
        /// </summary>
        /// <param name="currentClientId"></param>
        /// <returns></returns>
        public static String SetOrGetClientId(string currentClientId)
        {
            if (!GravitySDKUtil.IsEmptyString(currentClientId))
            {
                _clientID = currentClientId;
            }
            return _clientID;
        }

        public static void SetClientId(string clientId)
        {
            _clientID = clientId;
        }
        
        public static void SetSilentPeriod(int silentPeriod)
        {
            _silentPeriod = silentPeriod;
            _enableSilentPeriod = true;
        }
        
        public static String GetChannel()
        {
            return _channel;
        }

        public static bool IsDryRunModeEnabled()
        {
            return _isTencentDryRunModeEnabled;
        }

        public static void QueryDryRunInfo(string traceId, IQueryDryRunCallback queryDryRunCallback)
        {
            
            UnityWebRequestMgr.Instance.Get(
                    GravityHost + "/event_center/api/v1/event/postback_info/?access_token=" + _accessToken + "&client_id=" + SetOrGetClientId("") + "&trace_id=" + traceId,
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    // string responseText = "{\n  \"data\": {\n    \"postback_list\": [\n      {\n        \"trace_id\": \"8d7493023ad4690c2567fbb06bcf54f7\",\n        \"action\": \"pay\",\n        \"postback_value\": 30,\n        \"click_company\": \"tencent\",\n        \"timestamp\": 1680998892068\n      }\n    ]\n  },\n  \"extra\": {},\n  \"code\": 0,\n  \"msg\": \"成功\"\n}";
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                if (res.TryGetValue("data", out object dataObj))
                                {
                                    Dictionary<string, object> dataDict = (Dictionary<string, object>) dataObj;
                                    // foreach (var kvp in dataDict)
                                    // {
                                    //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                    // }
                                    if (dataDict.TryGetValue("postback_list", out object respObj))
                                    {
                                        Debug.Log(respObj);
                                        List<object> respList = (List<object>) Convert.ChangeType(respObj, typeof(List<object>));
                                        List<Dictionary<string, object>> finalList = new List<Dictionary<string, object>>();
                                        foreach (var item in respList)
                                        {
                                            Dictionary<string, object> itemDict = (Dictionary<string, object>) item;
                                            // foreach (var kvp in itemDict)
                                            // {
                                            //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                            // }

                                            finalList.Add(itemDict);
                                        }

                                        queryDryRunCallback?.onSuccess(finalList);
                                    }
                                    else
                                    {
                                        queryDryRunCallback?.onSuccess(new List<Dictionary<string, object>>());
                                    }
                                }
                                else
                                {
                                    queryDryRunCallback?.onSuccess(new List<Dictionary<string, object>>());
                                }
                                return;
                            }
                        }
                    }

                    queryDryRunCallback?.onFailed("code is not 0, failed with msg " + res?["msg"]);
                }), 2);
        }

        private static void SendDryRunInfo(List<Dictionary<string, string>> postBackList, ISendDryRunCallback sendDryRunCallback)
        {
            var requestDir = new Dictionary<string, object>()
            {
                {"postback_list", postBackList},
            };
            var body = GE_MiniJson.Serialize(requestDir);
            Debug.Log("request body is " + body);
            UnityWebRequestMgr.Instance.Post(
                    GravityHost + "/event_center/api/v1/event/postback_info/?access_token=" + _accessToken + "&client_id=" + SetOrGetClientId(""), requestDir,
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    // string responseText = "{\n  \"data\": {\n    \"postback_list\": [\n      {\n        \"trace_id\": \"8d7493023ad4690c2567fbb06bcf54f7\",\n        \"action\": \"pay\",\n        \"postback_value\": 30,\n        \"click_company\": \"tencent\",\n        \"timestamp\": 1680998892068\n      }\n    ]\n  },\n  \"extra\": {},\n  \"code\": 0,\n  \"msg\": \"成功\"\n}";
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                Debug.Log("send dry run info success");
                                sendDryRunCallback?.onSuccess();
                                return;
                            }
                        }
                    }
                    Debug.Log("code is not 0, failed with msg " + res?["msg"]);
                    sendDryRunCallback?.onFailed("code is not 0, failed with msg " + res?["msg"]);
                }));
        }

        public static void SendDryRunInfo(string traceId, string action, ISendDryRunCallback sendDryRunCallback)
        {
            List<Dictionary<string, string>> postBackList = new List<Dictionary<string, string>>();
            var postback = new Dictionary<string, string>()
            {
                {"trace_id",traceId},
                {"action", action}
            };
            postBackList.Add(postback);
            SendDryRunInfo(postBackList, sendDryRunCallback);
        }
        
        private static void SetupUserInfo(string action)
        {
            List<Dictionary<string, string>> postBackList = new List<Dictionary<string, string>>();
            var postback = new Dictionary<string, string>()
            {
                {"action", action}
            };
            postBackList.Add(postback);
            var requestDir = new Dictionary<string, object>()
            {
                {"postback_list", postBackList},
            };
            var body = GE_MiniJson.Serialize(requestDir);
            Debug.Log("request body is " + body);
            UnityWebRequestMgr.Instance.Post(
                    GravityHost + "/event_center/api/v1/event/tencent_sdk/?access_token=" + _accessToken + "&client_id=" + SetOrGetClientId(""), requestDir,
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + responseText);
                }));
        }
        
        // 腾讯SDK首次注册、沉默唤醒回传
        public static void TencentSDKRegisterTrack()
        {
            if (_silentPeriod <= 0 && _enableSilentPeriod)
            {
                GE_Log.e("silentPeriod must be set, not bellow zero.");
                return;
            }
            
            UnityWebRequestMgr.Instance.Get(
                    GravityHost + "/event_center/api/v1/event/tencent_sdk/?access_token=" + _accessToken + "&client_id=" + SetOrGetClientId("") + "&backFlowDay=" + _silentPeriod,
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    // string responseText = "{\n  \"data\": {\n    \"postback_list\": [\n      {\n        \"trace_id\": \"8d7493023ad4690c2567fbb06bcf54f7\",\n        \"action\": \"pay\",\n        \"postback_value\": 30,\n        \"click_company\": \"tencent\",\n        \"timestamp\": 1680998892068\n      }\n    ]\n  },\n  \"extra\": {},\n  \"code\": 0,\n  \"msg\": \"成功\"\n}";
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                if (res.TryGetValue("data", out object dataObj))
                                {
                                    Dictionary<string, object> dataDict = (Dictionary<string, object>) dataObj;
                                    // foreach (var kvp in dataDict)
                                    // {
                                    //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                    // }
                                    if (dataDict.TryGetValue("action", out object action))
                                    {
                                        Debug.Log(action);
#if GRAVITY_WECHAT_GAME_MODE && ENABLE_TENCENT_SDK_TRACK
                                        // 判断action，并且执行回调
                                        if (action.Equals("register"))
                                        {
                                            // 首次注册
                                            DnSdkHelper.onRegister();
                                            SetupUserInfo("register");
                                        } else if (action.Equals("re_active") && _enableSilentPeriod)
                                        {
                                            // 沉默唤醒
                                            DnSdkHelper.onReActive(_silentPeriod);
                                            SetupUserInfo("re_active");
                                        }
#endif
                                    }
                                    else
                                    {
                                        Debug.Log("action not valid");
                                    }
                                }
                                else
                                {
                                    Debug.Log("data not valid");
                                }
                                return;
                            }
                        }
                    }

                    Debug.Log("response is null");
                }));
        }
        
        public static void QueryAppConfigInfo()
        {
            UnityWebRequestMgr.Instance.Get(
                GravityHost + "/event_center/api/v1/base/appconf/?conf_type=dryrun_mode&access_token=" + _accessToken,
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    // string responseText = "{\n  \"data\": {\n    \"postback_list\": [\n      {\n        \"trace_id\": \"8d7493023ad4690c2567fbb06bcf54f7\",\n        \"action\": \"pay\",\n        \"postback_value\": 30,\n        \"click_company\": \"tencent\",\n        \"timestamp\": 1680998892068\n      }\n    ]\n  },\n  \"extra\": {},\n  \"code\": 0,\n  \"msg\": \"成功\"\n}";
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                if (res.TryGetValue("data", out object dataObj))
                                {
                                    Dictionary<string, object> dataDict = (Dictionary<string, object>) dataObj;
                                    // foreach (var kvp in dataDict)
                                    // {
                                    //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                    // }
                                    if (dataDict.TryGetValue("dryrun_mode", out object respObj))
                                    {
                                        Debug.Log(respObj);
                                        Dictionary<string, object> dryRunModeDic = (Dictionary<string, object>) respObj;
                                        foreach (var kvp in dryRunModeDic)
                                        {
                                            Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                        }
                                        if (dryRunModeDic.TryGetValue("tencent", out object tencentValue))
                                        {
                                            Debug.Log(tencentValue);
                                            int v = Convert.ToInt32(tencentValue);
                                            if (v != 0)
                                            {
                                                Debug.Log("tencent mode enabled");
                                                _isTencentDryRunModeEnabled = true;
                                                TryDryRunMode();
                                            }
                                            else
                                            {
                                                TencentSDKRegisterTrack();
                                            }
                                        }
                                        else
                                        {
                                            TencentSDKRegisterTrack();
                                        }
                                    }
                                    else
                                    {
                                        TencentSDKRegisterTrack();
                                    }
                                }
                                else
                                {
                                    TencentSDKRegisterTrack();
                                }
                            }
                            else
                            {
                                TencentSDKRegisterTrack();
                            }
                        }
                        else
                        {
                            TencentSDKRegisterTrack();
                        }
                    }
                    else
                    {
                        TencentSDKRegisterTrack();
                    }
                }));
        }
        
        public static void TryDryRunMode(int waitTime = 1, int retryCount = 0, int maxRetryInt = 0)
        {
            UnityWebRequestMgr.Instance.Get(
                GravityHost + "/event_center/api/v1/event/postback_info/?access_token=" + _accessToken + "&client_id=" + SetOrGetClientId(""),
                (request =>
                {
                    string responseText = request.downloadHandler.text;
                    // string responseText = "{\n  \"data\": {\n      \"postback_list\": [\n        {\n          \"trace_id\": \"your_order_id1\",\n          \"action\": \"pay\",\n          \"postback_value\": 10,\n          \"timestamp\": 1733371985420,\n          \"click_company\": \"tencent\"\n      },{\n          \"trace_id\": \"your_trace_id2\",\n          \"action\": \"create_role\",\n          \"postback_value\": 0,\n          \"role_name\": \"法师\",\n          \"timestamp\": 1733371985420,\n          \"click_company\": \"tencent\"\n      },\n        {\n          \"trace_id\": \"your_trace_id3\",\n          \"action\": \"tutorial_finish\",\n          \"postback_value\": 0,\n          \"role_name\": \"\",\n          \"timestamp\": 1733371985420,\n          \"click_company\": \"tencent\"\n      },{\n          \"trace_id\": \"your_trace_id4\",\n          \"action\": \"re_active\",\n          \"postback_value\": 0,\n          \"role_name\": \"\",\n          \"re_active_day\":10,\n          \"timestamp\": 1733371985420,\n          \"click_company\": \"tencent\"\n      }\n      ],\n      \"click_company\": \"tencent\",\n      \"retry\": 1\n  },\n  \"extra\": {},\n  \"code\": 0,\n  \"msg\": \"\\u6210\\u529f\"\n}";
                    
                    Dictionary<string, object> res = GE_MiniJson.Deserialize(responseText);
                    Debug.Log("response is " + retryCount + " " + responseText);
                    if (res != null)
                    {
                        if (res.TryGetValue("code", out var re))
                        {
                            int code = Convert.ToInt32(re);
                            if (code == 0)
                            {
                                if (res.TryGetValue("data", out object dataObj))
                                {
                                    Dictionary<string, object> dataDict = (Dictionary<string, object>) dataObj;
                                    // foreach (var kvp in dataDict)
                                    // {
                                    //     Debug.Log("key " + kvp.Key + " : " + kvp.Value?.ToString());
                                    // }
                                    if (maxRetryInt == 0)
                                    {
                                        if (dataDict.TryGetValue("retry", out var maxRetry))
                                        {
                                            maxRetryInt = Convert.ToInt32(maxRetry);
                                        }
                                    }

                                    if (dataDict.TryGetValue("postback_list", out object respObj))
                                    {
                                        Debug.Log(respObj);
                                        List<object> respList = (List<object>) Convert.ChangeType(respObj, typeof(List<object>));
                                        if (respList.Count == 0)
                                        {
                                            // 没有查到数据，可能需要retry
                                            if (maxRetryInt > retryCount)
                                            {
                                                Debug.Log("retry " + retryCount + " maxCount " + maxRetryInt + " wait time " + waitTime);
                                                TryDryRunMode(waitTime + 1, retryCount + 1, maxRetryInt);
                                            }
                                            return;
                                        }
                                        if (dataDict.TryGetValue("click_company", out var clickCompany))
                                        {
                                            if (!clickCompany.Equals("tencent"))
                                            {
                                                return;
                                            }
                                        }
                                        List<Dictionary<string, string>> postBackList = new List<Dictionary<string, string>>();
                                        foreach (var item in respList)
                                        {
                                            Dictionary<string, object> postbackDict = (Dictionary<string, object>) item;
                                            // foreach (var eachValue in postbackDict)
                                            // {
                                            //     Debug.Log("key " + eachValue.Key + " : " + eachValue.Value?.ToString() + " " + eachValue);
                                            // }
                                            string traceId = (string) postbackDict["trace_id"];
                                            string action = (string) postbackDict["action"];
                                            if (action.Equals("pay"))
                                            {
                                                int postbackValueInt = Convert.ToInt32(postbackDict["postback_value"]);

                                                Debug.Log("pay " + postbackValueInt);
#if GRAVITY_WECHAT_GAME_MODE && ENABLE_TENCENT_SDK_TRACK
                                                // 付费
                                                DnSdkHelper.onPurchase(postbackValueInt);
#endif
                                            } else if (action.Equals("create_role"))
                                            {
                                                string role_name = "";
                                                if (postbackDict.ContainsKey("role_name"))
                                                {
                                                    role_name = (string) postbackDict["role_name"];
                                                }
                                                Debug.Log("create_role " + role_name);
                                                GravityEngineAPI.TrackMPCreateRole(role_name);
                                            } else if (action.Equals("tutorial_finish"))
                                            {
                                                Debug.Log("tutorial_finish");
                                                GravityEngineAPI.TrackMPTutorialFinish();
                                            } else if (action.Equals("register"))
                                            {
                                                Debug.Log("register");
#if GRAVITY_WECHAT_GAME_MODE && ENABLE_TENCENT_SDK_TRACK
                                                // 首次注册
                                                DnSdkHelper.onRegister();
#endif
                                            } else if (action.Equals("re_active"))
                                            {
                                                int re_active_day = 0;
                                                if (postbackDict.ContainsKey("re_active_day"))
                                                {
                                                    re_active_day = Convert.ToInt32(postbackDict["re_active_day"]);
                                                }
                                                Debug.Log("re_active " + re_active_day);
#if GRAVITY_WECHAT_GAME_MODE && ENABLE_TENCENT_SDK_TRACK
                                                // 沉默唤醒
                                                DnSdkHelper.onReActive(re_active_day);
#endif
                                            }
                                            var postback = new Dictionary<string, string>()
                                            {
                                                {"trace_id",traceId},
                                                {"action", action}
                                            };
                                            postBackList.Add(postback);
                                        }

                                        if (postBackList.Count > 0)
                                        {
                                            Debug.Log("need to send postback count " + postBackList.Count);
                                            SendDryRunInfo(postBackList, null);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }), waitTime);
        }
    }
}