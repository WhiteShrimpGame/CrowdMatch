using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using WeChatWASM;

public class INSTANTGAMEEditor
{
    public static void UploadFirstBundle(EditorWindow window)
    {
        if (!WXConvertCore.IsInstantGameAutoStreaming())
        {
            Debug.Log("转换完成");
            window?.ShowNotification(new GUIContent("转换完成"));
        }
        else
        {
#if (UNITY_WEBGL || WEIXINMINIGAME) && UNITY_INSTANTGAME
                        // 上传首包资源
                        if (!string.IsNullOrEmpty(WXConvertCore.FirstBundlePath) && File.Exists(WXConvertCore.FirstBundlePath))
                        {
                            if (Unity.InstantGame.IGBuildPipeline.UploadWeChatDataFile(WXConvertCore.FirstBundlePath))
                            {
                                Debug.Log("转换完成并成功上传首包资源");
                                window?.ShowNotification(new GUIContent("转换完成并成功上传"));
                            }
                            else
                            {
                                Debug.LogError("首包资源上传失败，请检查网络以及Auto Streaming配置是否正确。");
                                window?.ShowNotification(new GUIContent("上传失败"));
                            }
                        }
                        else
                        {
                            Debug.LogError("转换失败");
                            window?.ShowNotification(new GUIContent("转换失败"));
                        }
#else
            window?.ShowNotification(new GUIContent("转换完成"));
#endif
        }
    }
}
