﻿#if UNITY_WEBGL || WEIXINMINIGAME || UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using WeChatWASM;

#if ENABLE_TMP
using TMPro;
#endif

namespace WXFunctionCompatibility
{
    public class WXInputMono : MonoBehaviour, IPointerClickHandler, IPointerExitHandler
    {
        private InputField input;

#if ENABLE_TMP
        private TMP_InputField tmpInput;
#endif

        private void Awake()
        {
            if (input == null)
            {
                input = GetComponent<InputField>();
            }

#if ENABLE_TMP
            if (input == null && tmpInput == null)
            {
                tmpInput = GetComponent<TMP_InputField>();
            }
#endif
        }

        private bool isShowKeyboad = false;
        private int waitFrame = 0;//等待帧数，避免打开后秒关闭
        private Coroutine coroutine_OnPointerExit;
        public void OnPointerClick(PointerEventData eventData)
        {
            if (coroutine_OnPointerExit != null)
                StopCoroutine(coroutine_OnPointerExit);
            ShowKeyboad();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (coroutine_OnPointerExit != null)
                StopCoroutine(coroutine_OnPointerExit);
            coroutine_OnPointerExit = StartCoroutine(IE_OnPorterExit());
        }


        private void Update()
        {
            if(waitFrame > 0)
            {
                waitFrame--;
                return;
            }

            if (!isShowKeyboad)
                return;

            TryHideKeyboad();
        }

        private void OnDisable()
        {
            TryHideKeyboad();
        }

        private void OnDestroy()
        {
            TryHideKeyboad();
        }

        IEnumerator IE_OnPorterExit()
        {
            yield return 0;
            TryHideKeyboad();
        }
        private void TryHideKeyboad()
        {
            // 隐藏输入法
            if (input != null)
            {
                if (!input.isFocused)
                {
                    HideKeyboad();
                }
            }
#if ENABLE_TMP
            if (tmpInput != null)
            {
                if (!tmpInput.isFocused)
                {
                    HideKeyboad();
                }
            }
#endif   
        }

        /// <summary>
        /// characterLimit 只约束交互输入，直接赋值 .text 不会截断，需自行限制长度。
        /// </summary>
        private static string ClampToCharacterLimit(string value, int characterLimit)
        {
            if (string.IsNullOrEmpty(value) || characterLimit <= 0 || value.Length <= characterLimit)
                return value;
            return value.Substring(0, characterLimit);
        }

        public void OnInput(OnKeyboardInputListenerResult v)
        {
            Debug.Log("onInput," + v.value);
            if (input != null)
            {
                if (input.isFocused)
                {
                    input.text = ClampToCharacterLimit(v.value, input.characterLimit);
                    // 原生键盘每次回写全量文本，光标会停在最前，手动移到末尾
                    int end = input.text.Length;
                    input.caretPosition = end;
                    input.selectionAnchorPosition = end;
                    input.selectionFocusPosition = end;
                }
            }

#if ENABLE_TMP
            if (tmpInput != null)
            {
                if (tmpInput.isFocused)
                {
                    tmpInput.text = ClampToCharacterLimit(v.value, tmpInput.characterLimit);
                    int end = tmpInput.text.Length;
                    tmpInput.caretPosition = end;
                    tmpInput.selectionAnchorPosition = end;
                    tmpInput.selectionFocusPosition = end;
                }
            }
#endif

        }

        public void OnConfirm(OnKeyboardInputListenerResult v)
        {
            // 输入法confirm回调
            Debug.Log("onConfirm");
            Debug.Log(v.value);
            HideKeyboad();
        }

        public void OnComplete(OnKeyboardInputListenerResult v)
        {
            // 输入法complete回调
            Debug.Log("OnComplete");
            Debug.Log(v.value);
            HideKeyboad();
        }

        private void ShowKeyboad()
        {
            if (!isShowKeyboad)
            {
                bool existInput = false;
                string text = "";
                if (input != null)
                {
                    existInput = true;
                    text = input.text;
                }

#if ENABLE_TMP
                if (tmpInput != null)
                {
                    existInput = true;
                    text = tmpInput.text;
                }
#endif
                if (!existInput)
                {
                    Debug.LogWarning("not exist input");
                    return;
                }

                int keyboardMaxLen = 20;
                if (input != null && input.characterLimit > 0)
                    keyboardMaxLen = input.characterLimit;
#if ENABLE_TMP
                else if (tmpInput != null && tmpInput.characterLimit > 0)
                    keyboardMaxLen = tmpInput.characterLimit;
#endif

#if UNITY_WEBGL && !UNITY_EDITOR
                WX.ShowKeyboard(new ShowKeyboardOption()
                {
                    defaultValue = text,
                    maxLength = keyboardMaxLen,
                    confirmType = "go"
                });

                //绑定回调
                WX.OnKeyboardConfirm(OnConfirm);
                WX.OnKeyboardComplete(OnComplete);
                WX.OnKeyboardInput(OnInput);
#endif
                isShowKeyboad = true;
                waitFrame = 1;
            }
        }

        private void HideKeyboad()
        {
            if (isShowKeyboad)
            {
#if UNITY_WEBGL && !UNITY_EDITOR
                WX.HideKeyboard(new HideKeyboardOption());
                //删除掉相关事件监听
                WX.OffKeyboardInput(OnInput);
                WX.OffKeyboardConfirm(OnConfirm);
                WX.OffKeyboardComplete(OnComplete);
#endif
                isShowKeyboad = false;
            }
        }
    }
}
#endif