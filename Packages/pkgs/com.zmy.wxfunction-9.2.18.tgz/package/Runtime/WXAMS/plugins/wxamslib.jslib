mergeInto(LibraryManager.library, {
  SetAMSDirectGameMaskStatus: function (isMasked) {
    if (window.WXWASMSDK && window.WXWASMSDK.SetAMSDirectGameMaskStatus) {
      window.WXWASMSDK.SetAMSDirectGameMaskStatus(isMasked !== 0);
    }
  },
  SetOpenId: function (openid) {
    var openidStr = UTF8ToString(openid);
    GameGlobal.dnSDK.setOpenId(openidStr);
  },
  onPurchase: function (purchaseValue,orderID) {
    var str_orderID = UTF8ToString(orderID);
    GameGlobal.dnSDK.track('PURCHASE',{
		value:purchaseValue,
		outer_action_id:str_orderID
	});
  },
  onRegister: function () {
    GameGlobal.dnSDK.onRegister();
  },
  onReActive: function (backFlowDay) {
    GameGlobal.dnSDK.track('RE_ACTIVE', {
      backFlowDay: backFlowDay
    });
  },
  onAddToWishlist: function (type) {
    var typeStr = UTF8ToString(type);
    GameGlobal.dnSDK.track('ADD_TO_WISHLIST', {
      type: typeStr
    });
  },
  onShare: function (target) {
    var targetStr = UTF8ToString(target);
    GameGlobal.dnSDK.track('SHARE', {
      target: targetStr
    });
  },
  onCreateRole: function (roleName) {
    var roleNameStr = UTF8ToString(roleName);
    GameGlobal.dnSDK.onCreateRole(roleNameStr);
  },
  START_LOAD: function () {
    var result = GameGlobal.dnSDK.track('START_LOAD',{});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS START_LOAD failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS START_LOAD success");
    }
  },
  LOAD_FINISH: function () {
    var result = GameGlobal.dnSDK.track('LOAD_FINISH',{});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS LOAD_FINISH failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS LOAD_FINISH success");
    }
  },
  RETENTION_5S: function () {
    var result = GameGlobal.dnSDK.track('RETENTION_5S',{});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS RETENTION_5S failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS RETENTION_5S success");
    }
  },
  onTutorialStart: function () {
    var result = GameGlobal.dnSDK.track('TUTORIAL_START',{});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS TUTORIAL_START failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS TUTORIAL_START success");
    }
  },
  onTutorialFinish: function () {
    var result = GameGlobal.dnSDK.onTutorialFinish();
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS TUTORIAL_FINISH failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS TUTORIAL_FINISH success");
    }
  },
  onUpdateLevel: function (level, power) {
    GameGlobal.dnSDK.track('UPDATE_LEVEL', {
      level: level,
      power: power,
    });
  },
  onViewContent: function (item) {
    var itemStr = UTF8ToString(item);
    GameGlobal.dnSDK.track('VIEW_CONTENT', {
      item: itemStr,
    });
  },
  LEVEL_ENTER: function (level_enter_data) {
    var level_enter_dataStr = UTF8ToString(level_enter_data);
    var jsonData = JSON.parse(level_enter_dataStr);

    const result = GameGlobal.dnSDK.track("LEVEL_ENTER", {
      enter_level_id: jsonData.enter_level_id,
      enter_level_name: jsonData.enter_level_name,
      game_mode: jsonData.game_mode,
      level_id: jsonData.level_id,
      chapter_id: jsonData.chapter_id,
      coin_amount: jsonData.coin_amount,
      stamina_value: jsonData.stamina_value,
      level_value: jsonData.level_value
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS LEVEL_ENTER failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS LEVEL_ENTER success");
    }
  },
  LEVEL_EXIT: function (level_exit_data) {
    var level_exit_dataStr = UTF8ToString(level_exit_data);
    var jsonData = JSON.parse(level_exit_dataStr);
    const result = GameGlobal.dnSDK.track("LEVEL_EXIT", {
      ad_cnt: jsonData.ad_cnt,
      duration: jsonData.duration,
      enter_level_id: jsonData.enter_level_id,
      game_mode: jsonData.game_mode,
      items: jsonData.items,
      level_id: jsonData.level_id,
      chapter_id: jsonData.chapter_id,
      coin_amount: jsonData.coin_amount,
      stamina_value: jsonData.stamina_value,
      level_value: jsonData.level_value
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS LEVEL_EXIT failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS LEVEL_EXIT success");
    }
  },
  LEVEL_LOSE: function (level_lose_data) {
    var level_lose_dataStr = UTF8ToString(level_lose_data);
    var jsonData = JSON.parse(level_lose_dataStr);
    const result = GameGlobal.dnSDK.track("LEVEL_LOSE", {
      ad_cnt: jsonData.ad_cnt,
      duration: jsonData.duration,
      enter_level_id: jsonData.enter_level_id,
      game_mode: jsonData.game_mode,
      items: jsonData.items,
      level_id: jsonData.level_id,
      chapter_id: jsonData.chapter_id,
      coin_amount: jsonData.coin_amount,
      stamina_value: jsonData.stamina_value,
      level_value: jsonData.level_value
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS LEVEL_LOSE failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS LEVEL_LOSE success");
    }
  },
  LEVEL_PASS: function (level_pass_data) {
    var level_pass_dataStr = UTF8ToString(level_pass_data);
    var jsonData = JSON.parse(level_pass_dataStr);
    const result = GameGlobal.dnSDK.track("LEVEL_PASS", {
      ad_cnt: jsonData.ad_cnt,
      duration: jsonData.duration,
      enter_level_id: jsonData.enter_level_id,
      game_mode: jsonData.game_mode,
      items: jsonData.items,
      level_id: jsonData.level_id,
      chapter_id: jsonData.chapter_id,
      coin_amount: jsonData.coin_amount,
      stamina_value: jsonData.stamina_value,
      level_value: jsonData.level_value
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS LEVEL_PASS failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS LEVEL_PASS success");
    }
  },
  AD_PLACEMENT_SHOW: function (ad_placement_name) {
    var result = GameGlobal.dnSDK.track('AD_PLACEMENT_SHOW', {
      ad_placement_name: ad_placement_name,
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS AD_PLACEMENT_SHOW failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS AD_PLACEMENT_SHOW success");
    }
  },
  AD_CLICK: function (ad_placement_name) {
    var result = GameGlobal.dnSDK.track('AD_CLICK', {
      ad_placement_name: ad_placement_name,
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS AD_CLICK failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS AD_CLICK success");
    }
  },
  AD_VIDEO_FINISH: function (ad_placement_name) {
    var result = GameGlobal.dnSDK.track('AD_VIDEO_FINISH', {
      ad_placement_name: ad_placement_name,
    });
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS AD_VIDEO_FINISH failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS AD_VIDEO_FINISH success");
    }
  },
  REWARD_AD_SHOW: function () {
    var result = GameGlobal.dnSDK.track('AD_IMPRESSION', {ad_type:1});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS REWARD_AD_SHOW failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS REWARD_AD_SHOW success");
    }
  },
  INTERSTITIAL_SHOW: function () {
    var result = GameGlobal.dnSDK.track('AD_IMPRESSION', {ad_type:2});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS INTERSTITIAL_SHOW failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS INTERSTITIAL_SHOW success");
    }
  },
  GRIDAD_SHOW: function () {
    var result = GameGlobal.dnSDK.track('AD_IMPRESSION', {ad_type:3});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS GRIDAD_SHOW failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS GRIDAD_SHOW success");
    }
  },
  BANNER_SHOW: function () {
    var result = GameGlobal.dnSDK.track('AD_IMPRESSION', {ad_type:4});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS BANNER_SHOW failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS BANNER_SHOW success");
    }
  },
  SUBSCRIBE: function () {
    var result = GameGlobal.dnSDK.track('SUBSCRIBE',{});
    if (result != undefined && result.code !== 0) {
      console.warn("WXAMS SUBSCRIBE failed, code:", result.code, "message:", result.message);
    }
    else if (result != undefined && result.code === 0) {
      console.log("WXAMS SUBSCRIBE success");
    }
  }
});