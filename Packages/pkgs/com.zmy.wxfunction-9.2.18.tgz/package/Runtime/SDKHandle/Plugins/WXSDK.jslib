mergeInto(LibraryManager.library, {
    GetJsonValue: function (key) {
        var str_key = _WXPointer_stringify_adaptor(key);
        var returnStr =  window.WXWASMSDK.GetJsonValue(str_key);
        
        var bufferSize = lengthBytesUTF8(returnStr) + 1;
        var buffer = _malloc(bufferSize);
        stringToUTF8(returnStr, buffer, bufferSize);
        return buffer;
    },
    CreateFeedBackButton: function (width , height , positionX , positionY , isShow)
    {
        window.WXWASMSDK.CreateFeedBackButton(width , height , positionX , positionY , isShow);
    },
    HideFeedBackButton: function ()
    {
        window.WXWASMSDK.HideFeedBackButton();
    },
    SubGameUpdate:function()
    {
        window.WXWASMSDK.SubGameUpdate();
    },
    GetSubGameUpdateStatus:function()
    {
        window.WXWASMSDK.GetSubGameUpdateStatus();
    },
	RequestSubscribe:function(tmplId)
	{
		var str_tmplId = _WXPointer_stringify_adaptor(tmplId);
		window.WXWASMSDK.RequestSubscribe(str_tmplId);
	},
    RequestSubscribeMulti:function(tmplIds)
    {
        var str_tmplIds = _WXPointer_stringify_adaptor(tmplIds);
        var tmplIdsArray = str_tmplIds.split(';');
        window.WXWASMSDK.RequestSubscribeMulti(tmplIdsArray);
    },
    GetABValue: function(key)
    {
        var str_key = _WXPointer_stringify_adaptor(key);
        var returnStr = window.WXWASMSDK.GetABValue(str_key);
        var bufferSize = lengthBytesUTF8(returnStr) + 1;
        var buffer = _malloc(bufferSize);
        stringToUTF8(returnStr, buffer, bufferSize);
        return buffer;
    },
    WXGetGameExptInfo: function () {
        window.WXWASMSDK.WXGetGameExptInfo();
    },
    CheckIsAddedToMyMiniProgram:function(invokeId)
    {
        window.WXWASMSDK.CheckIsAddedToMyMiniProgram(invokeId);
    },
    RequireOpenPrivacyAuthorize:function()
    {
        window.WXWASMSDK.RequireOpenPrivacyAuthorize();
    },
    GetPrivacySetting:function()
    {
        window.WXWASMSDK.GetPrivacySetting();
    },
    OnNeedPrivacyAuthorization:function(event)
    {
        window.WXWASMSDK.OnNeedPrivacyAuthorization(event);
    },
    OpenPrivacyContract:function()
    {
        window.WXWASMSDK.OpenPrivacyContract();
    },
    GetAuthorizeSetting:function(_withSubscriptions)
    {
        window.WXWASMSDK.GetAuthorizeSetting(_withSubscriptions);
    },
    IsSupportRecommend:function(){
        return !!window.wx.createPageManager;
    },
    PreloadRecommendJS:function(){
        var recommendPageManager = window.WXWASMSDK.GetOrCreateRecommendPageManager();

        if(recommendPageManager != null)
        {
            window.WXWASMSDK.PreLoadPageManager(recommendPageManager,{
                openlink: 'TWFRCqV5WeM2AkMXhKwJ03MhfPOieJfAsvXKUbWvQFQtLyyA5etMPabBehga950uzfZcH3Vi3QeEh41xRGEVFw',
            });
        }
    },
    ShowRecommend:function(){
        var recommendPageManager = window.WXWASMSDK.GetOrCreateRecommendPageManager();
        
        if(recommendPageManager != null)
        {
            window.WXWASMSDK.ShowPageManager(recommendPageManager,{
                openlink: 'TWFRCqV5WeM2AkMXhKwJ03MhfPOieJfAsvXKUbWvQFQtLyyA5etMPabBehga950uzfZcH3Vi3QeEh41xRGEVFw', 
            });
        }
    },

    GetOrCreatePageManager:function(tag)
    {
        var str_tag = _WXPointer_stringify_adaptor(tag);
        window.WXWASMSDK.GetOrCreatePageManager(str_tag);
    },

    ShowCPSPageManager:function(tag,id,left,top,vertical)
    {
        var str_tag = _WXPointer_stringify_adaptor(tag);
        var str_id = _WXPointer_stringify_adaptor(id);
        window.WXWASMSDK.ShowCPSPageManager(str_tag,str_id,left,top,vertical);
    },
    DestroyCPSPageManager:function(tag)
    {
        var str_tag = _WXPointer_stringify_adaptor(tag);
        window.WXWASMSDK.DestroyPageManager(str_tag);
    },
	GetWXDATA_CDN: function()
    {
        var returnStr = window.WXWASMSDK.GetWXDATA_CDN();
        var bufferSize = lengthBytesUTF8(returnStr) + 1;
        var buffer = _malloc(bufferSize);
        stringToUTF8(returnStr, buffer, bufferSize);
        return buffer;
    },
    WXMiniGameCommonGetUserLabelV2:function(gift_scene,gift_name,gift_value,gift_value_success,tt_action,callBackId)
    {
        var str_gift_scene = _WXPointer_stringify_adaptor(gift_scene);
        var str_gift_name = _WXPointer_stringify_adaptor(gift_name);
        var str_tt_action = _WXPointer_stringify_adaptor(tt_action);
        window.WXWASMSDK.WXMiniGameCommonGetUserLabelV2(str_gift_scene,str_gift_name,gift_value,gift_value_success,str_tt_action,callBackId);
    },
    WXMiniGameCommonGetUserLabel:function(gift_scene,gift_name,gift_value,gift_value_success,tt_action,callBackId)
    {
        var str_gift_scene = _WXPointer_stringify_adaptor(gift_scene);
        var str_gift_name = _WXPointer_stringify_adaptor(gift_name);
		var str_tt_action = _WXPointer_stringify_adaptor(tt_action);
        window.WXWASMSDK.WXMiniGameCommonGetUserLabel(str_gift_scene,str_gift_name,gift_value,gift_value_success,str_tt_action,callBackId);
    },
	WXGetSign:function(appid,appKey)
	{
		var str_appid = _WXPointer_stringify_adaptor(appid);
        var str_appKey = _WXPointer_stringify_adaptor(appKey);
		var returnStr = window.WXWASMSDK.WXGetSign(str_appid,str_appKey);
		var bufferSize = lengthBytesUTF8(returnStr) + 1;
        var buffer = _malloc(bufferSize);
        stringToUTF8(returnStr, buffer, bufferSize);
        return buffer;
	},
    WXMiniGameCommonGetLiveBattleRankManager:function(callBackId)
    {
        window.WXWASMSDK.WXMiniGameCommonGetLiveBattleRankManager(callBackId);
    },
    WXMiniGameCommonLiveBattleUpdateScore:function(score,callBackId)
    {
        window.WXWASMSDK.WXMiniGameCommonLiveBattleUpdateScore(score,callBackId);
    },
    WXMiniGameCommonCanIUseShareImageToGameCenter:function()
    {
        return window.WXWASMSDK.WXMiniGameCommonCanIUseShareImageToGameCenter() ? 1 : 0;
    },
    WXMiniGameCommonShareImageToGameCenter:function(path,title,content,callBackId)
    {
        var str_path = _WXPointer_stringify_adaptor(path);
        var str_title = _WXPointer_stringify_adaptor(title);
        var str_content = _WXPointer_stringify_adaptor(content);
        window.WXWASMSDK.WXMiniGameCommonShareImageToGameCenter(str_path,str_title,str_content,callBackId);
    },
    WXChallengeIsValid:function()
    {
        return window.WXWASMSDK.WXChallengeIsValid();
    },
    WXUpdateScore:function(scoreKey,score)
    {
        var str_scoreKey = _WXPointer_stringify_adaptor(scoreKey);
        window.WXWASMSDK.WXUpdateScore(str_scoreKey,score);
    },
    WXCreateChallenge:function(scoreKey)
    {
        var str_scoreKey = _WXPointer_stringify_adaptor(scoreKey);
        window.WXWASMSDK.WXCreateChallenge(str_scoreKey);
    },
    WXEndChallenge:function(scoreKey,score)
    {
        var str_scoreKey = _WXPointer_stringify_adaptor(scoreKey);
        window.WXWASMSDK.WXEndChallenge(str_scoreKey,score);
    },
    WXOnChallengeStart:function()
    {
        window.WXWASMSDK.WXOnChallengeStart();
    },
    WXChallengeMiddleUpdate:function(scoreKey,score)
    {
        var str_scoreKey = _WXPointer_stringify_adaptor(scoreKey);
        window.WXWASMSDK.WXChallengeMiddleUpdate(str_scoreKey,score);
    },
    WXQuitChallenge:function()
    {
        window.WXWASMSDK.WXQuitChallenge();
    },
    IsInitWXAMS:function()
    {
        return window.WXWASMSDK.IsInitWXAMS;
    },
    WXGetDirectAdStatus:function()
    {
        window.WXWASMSDK.WXGetDirectAdStatus();
    },
    WXOnDirectAdStatusChange:function()
    {
        window.WXWASMSDK.WXOnDirectAdStatusChange();
    },
    WXCheckIsSupportMidasPayment:function()
    {
        return window.WXWASMSDK.WXCheckIsSupportMidasPayment();
    },

    // ===== VideoDecoder + MediaAudioPlayer bridge =====
    _wxMediaAudioPlayer: null,

    // Check if platform supports VideoDecoder + MediaAudioPlayer
    WXIsMediaAudioSupported: function() {
        return !!(typeof wx !== 'undefined' && wx.createVideoDecoder && wx.createMediaAudioPlayer);
    },

    // iOS high-perf OR high-perf+: use frame event path (wemedia decoder)
    WXIsIOSWemediaPath: function() {
        try {
            return typeof GameGlobal !== 'undefined' &&
                   !!(GameGlobal.isIOSHighPerformanceMode || GameGlobal.isIOSHighPerformanceModePlus);
        } catch(e) { return false; }
    },

    // iOS high-perf+ only: needs videoDataType:2
    WXIsIOSHighPerfPlus: function() {
        try {
            return typeof GameGlobal !== 'undefined' && !!GameGlobal.isIOSHighPerformanceModePlus;
        } catch(e) { return false; }
    },

    // Install a hook on wx.createVideoDecoder so the NEXT call to WX.CreateVideoDecoder() on the
    // C# side automatically caches the instance into window._wxDecoderInst.
    // Also cleans up any previous decoder/audio state.
    // useIOSPerf: if true, the frame event is bound immediately after creation.
    // initialVolume: 0.0 = muted, 1.0 = full volume (applied when MediaAudioPlayer starts)
    WXHookAndReset: function(useIOSPerf, initialVolume) {
        if (typeof wx === 'undefined' || !wx.createVideoDecoder) return;

        // store the desired initial volume for use inside onStarted
        window._wxDecoderInitialVolume = initialVolume;
        window._wxDecoderUseIOSPerf    = !!useIOSPerf;
        window._wxDecoderAborted       = false;

        // clean up previous JS instances
        var oldAudio = window._wxMediaAudioPlayerInst;
        var oldDec   = window._wxDecoderInst;
        var oldFrame = window._wxDecoderPerfLatestFrame;
        window._wxMediaAudioPlayerInst   = null;
        window._wxDecoderInst             = null;
        window._wxDecoderPerfLatestFrame  = null;
        if (oldFrame && oldFrame.close) { try { oldFrame.close(); } catch(e) {} }
        if (oldAudio) {
            try { oldAudio.stop().then(function(){ oldAudio.destroy().catch(function(){}); }).catch(function(){}); } catch(e) {}
        }
        if (oldDec) {
            try { var sp = oldDec.stop();  if (sp && sp.then) sp.catch(function(){}); } catch(e) {}
            try { var rp = oldDec.remove(); if (rp && rp.then) rp.catch(function(){}); } catch(e) {}
        }

        // (Re-)install hook - preserve original so we don't double-wrap
        var _orig = window.__wxDecoderOrigCreate || wx.createVideoDecoder.bind(wx);
        window.__wxDecoderOrigCreate = _orig;
        wx.createVideoDecoder = function(opts) {
            // iOS wemedia path requires { type: "wemedia" } to enable frame events
            var finalOpts = opts;
            if (window._wxDecoderUseIOSPerf) {
                finalOpts = (opts && typeof opts === 'object') ? opts : {};
                if (!finalOpts.type) finalOpts.type = 'wemedia';
            }
            var dec = _orig(finalOpts);
            window._wxDecoderInst = dec;
            window._wxDecoderPerfLatestFrame = null;
            // frame event: bind for both iOS high-perf and high-perf+
            if (window._wxDecoderUseIOSPerf && dec && dec.on) {
                dec.on('frame', function(res) {
                    if (window._wxDecoderPerfLatestFrame && window._wxDecoderPerfLatestFrame.close) {
                        try { window._wxDecoderPerfLatestFrame.close(); } catch(e) {}
                    }
                    window._wxDecoderPerfLatestFrame = res || null;
                });
            }
            return dec;
        };
    },

    // Start the decoder instance that was just captured via the hook.
    // Supports both Promise-based start (new SDK) and event-based "start" callback (legacy SDK).
    // On success: creates MediaAudioPlayer, adds decoder as source, applies initial volume,
    // then notifies C# via SendMessage(callbackObj, callbackMethod, "width,height").
    WXStartDecoder: function(src, mode, videoDataType, callbackObj, callbackMethod) {
        var dec = window._wxDecoderInst;
        if (!dec) {
            console.warn('[WXDecoder] WXStartDecoder: no decoder - did you call WXHookAndReset before WX.CreateVideoDecoder()?');
            return;
        }
        var srcStr   = UTF8ToString(src);
        var cbObj    = UTF8ToString(callbackObj);
        var cbMethod = UTF8ToString(callbackMethod);
        var opt = { source: srcStr, mode: mode | 0 };
        if (videoDataType > 0) opt.videoDataType = videoDataType | 0;

        function sendToCS(w, h) {
            // Guard: if destroyed before async callbacks fire, skip SendMessage to avoid Wasm crash
            if (window._wxDecoderAborted) {
                console.warn('[WXDecoder] sendToCS skipped: decoder was destroyed');
                return;
            }
            var payload = (w || 0) + ',' + (h || 0);
            try {
                // WeChat mini-game: GameGlobal.Module.SendMessage (primary)
                if (typeof GameGlobal !== 'undefined' && GameGlobal.Module && GameGlobal.Module.SendMessage)
                    GameGlobal.Module.SendMessage(cbObj, cbMethod, payload);
                else if (typeof GameGlobal !== 'undefined' && GameGlobal.manager && GameGlobal.manager.SendMessage)
                    GameGlobal.manager.SendMessage(cbObj, cbMethod, payload);
                else if (typeof GameInstance !== 'undefined' && GameInstance.SendMessage)
                    GameInstance.SendMessage(cbObj, cbMethod, payload);
                else if (typeof unityInstance !== 'undefined' && unityInstance.SendMessage)
                    unityInstance.SendMessage(cbObj, cbMethod, payload);
                else
                    console.warn('[WXDecoder] sendToCS: no SendMessage found, cbObj=' + cbObj);
            } catch(e) { console.warn('[WXDecoder] SendMessage failed', e); }
        }

        function onStarted(info) {
            var w = (info && info.width)  || 0;
            var h = (info && info.height) || 0;
            var initVol = (window._wxDecoderInitialVolume !== undefined) ? window._wxDecoderInitialVolume : 0;
            try {
                var audio = wx.createMediaAudioPlayer();
                window._wxMediaAudioPlayerInst = audio;
                // Apply initial volume BEFORE start() so there is never an audible blip
                try { audio.volume = initVol; } catch(e) {}
                audio.start().then(function() {
                    return audio.addAudioSource(dec);
                }).then(function() {
                    // re-apply volume after addAudioSource (some SDK versions reset it)
                    try { audio.volume = initVol; } catch(e) {}
                    // decoder.mute for iOS perf+
                    // mute API: used for iOS wemedia path (high-perf and high-perf+)
                    if (window._wxDecoderUseIOSPerf && typeof dec.mute === 'function') {
                        try { dec.mute(initVol === 0); } catch(e) {}
                    }
                    try { var sk = dec.seek(0); sk && sk.then && sk.catch(function(){}); } catch(e) {}
                    sendToCS(w, h);
                }).catch(function(e) {
                    console.warn('[WXDecoder] addAudioSource failed', e);
                    sendToCS(w, h);
                });
            } catch(e) {
                console.warn('[WXDecoder] MediaAudioPlayer error', e);
                sendToCS(w, h);
            }
        }

        var legacyHandled = false;
        function onLegacyStart(info) {
            if (legacyHandled) return;
            legacyHandled = true;
            try { dec.off && dec.off('start', onLegacyStart); } catch(e) {}
            onStarted(info || {});
        }
        dec.on && dec.on('start', onLegacyStart);

        var startP = dec.start(opt);
        if (startP && typeof startP.then === 'function') {
            legacyHandled = true;
            try { dec.off && dec.off('start', onLegacyStart); } catch(e) {}
            startP.then(onStarted).catch(function(e) {
                console.warn('[WXDecoder] start() rejected', e);
                // Still notify C# so the coroutine can start pulling frames (iOS wemedia path may
                // reject start() but still emit frame events normally)
                sendToCS(0, 0);
            });
        }
    },

    // Set volume via MediaAudioPlayer (non-iOS-perf path)
    WXMediaAudioSetVolume: function(vol) {
        var inst = window._wxMediaAudioPlayerInst;
        if (!inst) return;
        try { inst.volume = vol; } catch(e) {}
    },

    // Set mute via VideoDecoder.mute (iOS perf+ path)
    WXDecoderMute: function(muted) {
        var dec = window._wxDecoderInst;
        if (!dec || typeof dec.mute !== 'function') return;
        try { dec.mute(!!muted); } catch(e) {}
    },

    // Destroy decoder and MediaAudioPlayer
    WXDestroyDecoder: function() {
        // Mark aborted FIRST so any in-flight async callbacks (addAudioSource.then -> sendToCS)
        // will not fire SendMessage to an already-destroyed GameObject (prevents Wasm crash)
        window._wxDecoderAborted = true;
        var audio = window._wxMediaAudioPlayerInst;
        var dec   = window._wxDecoderInst;
        var frame = window._wxDecoderPerfLatestFrame;
        window._wxMediaAudioPlayerInst   = null;
        window._wxDecoderInst             = null;
        window._wxDecoderPerfLatestFrame  = null;
        if (frame && frame.close) { try { frame.close(); } catch(e) {} }
        if (audio) { try { audio.stop().then(function(){ audio.destroy().catch(function(){}); }).catch(function(){}); } catch(e) {} }
        if (dec)   {
            try { var sp = dec.stop();  if (sp && sp.then) sp.catch(function(){}); } catch(e) {}
            try { var rp = dec.remove(); if (rp && rp.then) rp.catch(function(){}); } catch(e) {}
        }
    },

    // Pull one RGBA frame (standard getFrameData path, flipped vertically).
    WXGetFrameData: function(outWidth, outHeight, outBuffer, outBufferSize) {
        var dec = window._wxDecoderInst;
        if (!dec) return 0;
        var frame = null;
        try { frame = dec.getFrameData(); } catch(e) { return 0; }
        if (!frame) return 0;
        // _resolveUploadPayload: data may be ArrayBuffer or TypedArray
        var frameData = frame.data !== undefined ? frame.data : frame;
        if (!frameData) return 0;
        var src;
        if (frameData instanceof Uint8ClampedArray || frameData instanceof Uint8Array) {
            src = frameData;
        } else if (frameData instanceof ArrayBuffer) {
            src = new Uint8Array(frameData);
        } else if (frameData && frameData.buffer instanceof ArrayBuffer) {
            src = new Uint8Array(frameData.buffer);
        } else {
            src = new Uint8Array(frameData);
        }
        var w = (frame.width  || (src.length / 4 > 0 ? Math.sqrt(src.length / 4) | 0 : 0)) | 0;
        var h = (frame.height || (w > 0 ? (src.length / 4 / w) | 0 : 0)) | 0;
        if (w <= 0 || h <= 0) return 0;
        var needed = w * h * 4;
        if (needed <= 0 || needed > outBufferSize) return 0;
        HEAP32[outWidth  >> 2] = w;
        HEAP32[outHeight >> 2] = h;
        var rowBytes = w * 4;
        for (var y = 0; y < h; y++) {
            var srcOff = (h - 1 - y) * rowBytes;
            HEAPU8.set(src.subarray(srcOff, srcOff + rowBytes), outBuffer + y * rowBytes);
        }
        return needed;
    },

    // Pull one RGBA frame from iOS perf+ frame event (videoDataType=2 path, flipped vertically).
    WXGetFrameDataPerf: function(outWidth, outHeight, outBuffer, outBufferSize) {
        var packet = window._wxDecoderPerfLatestFrame;
        window._wxDecoderPerfLatestFrame = null;
        if (!packet) return 0;
        try {
            var frameData = packet.data !== undefined ? packet.data : packet;
            var src;
            if (frameData instanceof Uint8ClampedArray || frameData instanceof Uint8Array) {
                src = frameData;
            } else if (frameData && frameData.buffer instanceof ArrayBuffer) {
                src = new Uint8Array(frameData.buffer);
            } else {
                src = new Uint8Array(frameData);
            }
            var w = (packet.width  | 0);
            var h = (packet.height | 0);
            if (w <= 0 || h <= 0) return 0;
            var needed = w * h * 4;
            if (needed <= 0 || needed > outBufferSize) return 0;
            HEAP32[outWidth  >> 2] = w;
            HEAP32[outHeight >> 2] = h;
            var rowBytes = w * 4;
            for (var y = 0; y < h; y++) {
                var srcOff = (h - 1 - y) * rowBytes;
                HEAPU8.set(src.subarray(srcOff, srcOff + rowBytes), outBuffer + y * rowBytes);
            }
            return needed;
        } catch(e) {
            return 0;
        } finally {
            try { packet.close && packet.close(); } catch(e) {}
        }
    },

});
